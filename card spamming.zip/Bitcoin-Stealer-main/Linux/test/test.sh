#!/bin/bash

node test.js
