#!/bin/bash
node generator.js
$SHELL
