# NOTE LINUX USERS!

Make sure you right click on the .sh file and select Properties -> Permissions and make sure the "allow executing file as program" is checked (enabled). And then to run the run.sh script, you have two options:

- (Easiest way) You can double click on the .sh file and select "run in terminal"

- Or you can right click on the project folder, select "open in terminal" and then execute the script manually with the following command example: "./run.sh" and hit enter.
